#include "diffdrive_arduino/arm.h"

#include <cmath>


Arm::Arm(const std::string &arm_name, double position)
{
  
}


